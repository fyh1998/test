# -*- coding:utf-8 -*-
import codecs
import os
import jieba
import string
import re
from pygraph.classes.digraph import digraph
import PR
import operator

def mkdir(path):
    path = path.strip()
    path = path.rstrip("\\")
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
        return True
    else:
        return False

def stopwordslist(filepath):
    stopwords = [line.strip() for line in open(filepath, 'r').readlines()]
    return stopwords


if __name__ == '__main__':
    datapath = "C:/Users/lenovo/Desktop/bilibili/data_danmaku/"  # 这是数据读取后存放结果的data_danmaku的路径，前面部分改一下
    rankpath = "C:/Users/lenovo/Desktop/bilibili/rank_danmaku/"  # 这是存储弹幕评分的文件夹
    mkdir(rankpath)
    pathDir = os.listdir(datapath)
    for allDir in pathDir:
        filepath1 = os.path.join(datapath, allDir)
        filepath2 = os.path.join(rankpath, allDir)
        f1 = codecs.open(filepath1, encoding='utf-8')
        f2 = open(filepath2, "w")
        danmu_lst = f1.readlines()
        danmudata_mat = []
        for item in danmu_lst:
            out = re.sub('[%s]' % re.escape(string.punctuation), '', item)
            s = re.sub("[\s+\.\!\/_,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）≧▽≦∩]+", "", out)
            seg_list = jieba.cut(s)
            segLst = "/".join(seg_list).split("/")
            stopwords = stopwordslist('C:/Users/lenovo/Desktop/bilibili/stopwords.txt')
            wordLst = []
            for word in segLst:
                if word not in stopwords:
                    wordLst.append(word)
            danmudata_mat.append(wordLst)
        index_lst = []
        word_mat = []
        for i in range(len(danmudata_mat)):
            if len(danmudata_mat[i]) and danmudata_mat[i] not in word_mat:
                index_lst.append(i)
                word_mat.append(danmudata_mat[i])

        danmu_mat = []
        for i in range(len(word_mat)):
            word_link = []
            for word in word_mat[i]:
                for j in range(len(word_mat)):
                    if i != j:
                        if word in word_mat[j] and j not in word_link:
                            word_link.append(j)
            danmu_mat.append(word_link)
        if len(word_mat)>3:
            dg = digraph()
            nodes = []
            for i in range(len(danmu_mat)):
                nodes.append(str(i))
            dg.add_nodes(nodes)
            for i in range(len(danmu_mat)):
                if len(danmu_mat[i]) == 0:
                    continue
                for j in danmu_mat[i]:
                    dg.add_edge((str(i), str(j)))

            pr = PR.PRIterator(dg)
            page_ranks = pr.page_rank()
            sorted_pagerank = sorted(page_ranks.items(), key=operator.itemgetter(1))
            for i in range(3):
                try:
                    f2.write(danmu_lst[index_lst[int(sorted_pagerank[-i][0])]])
                except:
                    continue
        else:
            f2.write("danmaku is empty!")
