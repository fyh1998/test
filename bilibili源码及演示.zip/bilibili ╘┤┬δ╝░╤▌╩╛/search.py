import web, sys, os, lucene, jieba, re, math, cv2
from web import form
from s import*

from bs4 import BeautifulSoup
from java.io import File
from org.apache.lucene.analysis.standard import StandardAnalyzer
from org.apache.lucene.index import DirectoryReader
from org.apache.lucene.queryparser.classic import QueryParser
from org.apache.lucene.store import SimpleFSDirectory
from org.apache.lucene.search import IndexSearcher
from org.apache.lucene.util import Version
from org.apache.lucene.analysis.core import WhitespaceAnalyzer
from org.apache.lucene.search import BooleanQuery
from org.apache.lucene.search import BooleanClause

reload(sys)
sys.setdefaultencoding('utf-8')
render = web.template.render('templates/')

def get_h(img,y_start,y_end,x_start,x_end):
    h = [0,0,0]
    for y in range(y_start,y_end):
            for x in range(x_start,x_end):
                for i in range(3):
                    h[i] += img[y][x][i]
    s = sum(h)
    for i in range(3):
        h[i] /= float(s)
    return h

def get_feature(img,I):
    len_x = len(img[0])
    len_y = len(img)
    bd_x = len_x/2
    bd_y = len_y/2
    h1 = get_h(img,0,bd_y,0,bd_x)
    h2 = get_h(img,0,bd_y,bd_x,len_x)
    h3 = get_h(img,bd_y,len_y,0,bd_x)
    h4 = get_h(img,bd_y,len_y,bd_x,len_x)
    p = h1 + h2 + h3 + h4   #get p
    v = ""
    for i in range(12):     #get v(p)
        if p[i] < 0.3:
            p[i] = 0
            v += "00"
        elif p[i] <0.6:
            p[i] = 1
            v += "01"
        else:
            p[i] = 2
            v += "11"
    g = ""             #get g(p)
    for i in I:
        g += v[i]
        g += ' '
    return p,g[:-1]

def sortbyscore(dic):
    flag = 10
    length = len(dic)
    while(flag):
        flag = 0
        for i in range(1,length):
            if dic[i-1][0] < dic[i][0]:
                temp = dic[i-1]
                dic[i-1] = dic[i]
                dic[i] = temp
                flag += 1
    return dic

def sortbydis(dic):
    flag = 10
    length = len(dic)
    while(flag):
        flag = 0
        for i in range(1,length):
            if dic[i-1][0] > dic[i][0]:
                temp = dic[i-1]
                dic[i-1] = dic[i]
                dic[i] = temp
                flag += 1
    return dic

def searchbyimage(filename):
    vm_env.attachCurrentThread()
    I = [1,4,7,10,13,16,19,22]
    filepath = 'userdata/'+filename
    img = cv2.imread(filepath,cv2.IMREAD_COLOR)
    imgfeature,imgtype = get_feature(img,I)
    #print imgfeature,imgtype
    query = QueryParser(Version.LUCENE_CURRENT, "pic_type",
                            analyzer).parse(imgtype)
    scoreDocs = searcher_img.search(query, 100).scoreDocs
    print "%s total matching documents." % len(scoreDocs)
    dic = []
    for scoreDoc in scoreDocs:
        doc = searcher_img.doc(scoreDoc.doc)
        feature = doc.get('pic_feature')
        avid = doc.get('aid')
        title = doc.get('title')
        imgurl = doc.get('img_url')
        score = 0
        url = "https://www.bilibili.com/video/av"+avid
        for i in range(len(imgfeature)):
            score += math.pow(int(feature.split(' ')[i])-int(imgfeature[i]),2)
        tmp = []
        tmp.append(score)
        tmp.append(imgurl)
        tmp.append(title)
        tmp.append(avid)
        tmp.append(url)
        dic.append(tmp)
    sortdic = sortbydis(dic)
    return sortdic

def searchbyword(command):
    vm_env.attachCurrentThread()
    command = unicode(command, 'utf-8')
    seg = jieba.cut(command)
    command = ' '.join(seg)
    query = QueryParser(Version.LUCENE_CURRENT, "content",
                            analyzer).parse(command)
    scoreDocs = searcher.search(query, 50).scoreDocs
    print "%s total matching documents." % len(scoreDocs)
    dic = []
    for scoreDoc in scoreDocs:
        doc = searcher.doc(scoreDoc.doc)
        avid = doc.get('aid')
        title = doc.get('title')
        imgurl = doc.get('img_url')
        score = float(doc.get('score'))
        if command in title:
            score+=50
        danmu = doc.get('danmu')
        danmu_l = danmu.split('\t')
        url = "https://www.bilibili.com/video/av"+avid
        tmp = []
        tmp.append(score)
        tmp.append(imgurl)
        tmp.append(title)
        tmp.append(avid)
        tmp.append(danmu_l)
        tmp.append(url)
        dic.append(tmp)
    sortdic = sortbyscore(dic)
    return sortdic

urls = (
    '/','index',
    '/word','word',
    '/image','image',
)

class index:
    def GET(self):
        return render.searchimage()
    def POST(self):
        user_data = web.input(myimg={})
        if "myimg" in user_data:
            filepath=user_data.myimg.filename.replace('\\','/') # replaces the windows-style slashes with linux ones.
            #print filepath
            filename=filepath.split('/')[-1] # splits the and chooses the last part (the filename with extension)
            fout = open('userdata/'+ filename,'w') # creates the file where the uploaded file should be stored
            fout.write(user_data.myimg.file.read()) # writes the uploaded file to the newly created file.
            fout.close() # closes the file, upload complete.

class word:
    def GET(self):
        user_data = web.input(mytext={})
        if user_data.mytext == '':
            return render.searchimage()
        a = searchbyword(user_data.mytext)
        return render.resultimg(a)

class image:
    def GET(self):
        user_data = web.input(myimg={})
        filepath=user_data.myimg.filename.replace('\\','/')
        filename=filepath.split('/')[-1]
        if filename == '':
            return render.searchimage()
        a = searchbyimage(filename)
        return render.resultbyimage(a)
    def POST(self):
        user_data = web.input(myimg={})
        if "myimg" in user_data:
            filepath=user_data.myimg.filename.replace('\\','/') # replaces the windows-style slashes with linux ones.
            #print filepath
            filename=filepath.split('/')[-1] # splits the and chooses the last part (the filename with extension)
            fout = open('userdata/'+ filename,'w') # creates the file where the uploaded file should be stored
            fout.write(user_data.myimg.file.read()) # writes the uploaded file to the newly created file.
            fout.close() # closes the file, upload complete.
            if filename == '':
                return render.searchimage()
            a = searchbyimage(filename)
            #print filename
            return render.resultbyimage(a)



#class image:


if __name__ == '__main__':
    app = web.application(urls,globals())
    app.run()
    del searcher,searcher_img
