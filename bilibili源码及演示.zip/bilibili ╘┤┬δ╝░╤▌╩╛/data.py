# -*- coding:utf-8 -*-
import os
import codecs

datapath = "C:/Users/lenovo/Desktop/bilibili/data_html/"#这是第二步将要进行的数据读取后存放结果的data_html的路径，前面部分改一下
danmupath = "C:/Users/lenovo/Desktop/bilibili/rank_danmaku/" # 这是存储弹幕评分的文件夹
folder = 'C:/Users/lenovo/Desktop/bilibili/data'  #存储结果的文件夹，没有的话会创建一个同名的
if not os.path.exists(folder):
    os.mkdir(folder)
pathDir = os.listdir(danmupath)
for allDir in pathDir:
    filepath1 = os.path.join(datapath, allDir)
    filepath2 = os.path.join(danmupath, allDir)
    filepath3 = os.path.join(folder, allDir)
    f1 = open(filepath1)
    f2 = open(filepath2)
    f3 = open(filepath3, 'w')
    data_lst = f1.readlines()
    danmu_lst = f2.readlines()
    for danmu in danmu_lst:
        item =danmu.decode("gbk").encode("utf8")
        data_lst.append(item)
    f3.writelines(data_lst)