import sys, os, lucene, jieba

from java.io import File
from org.apache.lucene.analysis.standard import StandardAnalyzer
from org.apache.lucene.index import DirectoryReader
from org.apache.lucene.queryparser.classic import QueryParser
from org.apache.lucene.store import SimpleFSDirectory
from org.apache.lucene.search import IndexSearcher
from org.apache.lucene.util import Version
from org.apache.lucene.analysis.core import WhitespaceAnalyzer

vm_env = lucene.initVM()
vm_env.attachCurrentThread()
STORE_DIR = "index"
STORE_IMG = "index_img"
#lucene.initVM(vmargs=['-Djava.awt.headless=true'])
directory = SimpleFSDirectory(File(STORE_DIR))
directory_img = SimpleFSDirectory(File(STORE_IMG))
searcher = IndexSearcher(DirectoryReader.open(directory))
searcher_img = IndexSearcher(DirectoryReader.open(directory_img))
analyzer = StandardAnalyzer(Version.LUCENE_CURRENT)
