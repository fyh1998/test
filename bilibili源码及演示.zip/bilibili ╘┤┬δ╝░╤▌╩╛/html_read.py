# -*- coding:utf-8 -*-
import os
import re
import math
import cv2
import urllib
def get_h(img,y_start,y_end,x_start,x_end):
    h = [0,0,0]
    for y in range(y_start,y_end):
            for x in range(x_start,x_end):
                for i in range(3):
                    h[i] += img[y][x][i]
    s = sum(h)
    for i in range(3):
        h[i] /= float(s)
    return h
    
def get_feature(img,I):
    len_x = len(img[0])
    len_y = len(img)
    bd_x = len_x/2
    bd_y = len_y/2
    h1 = get_h(img,0,bd_y,0,bd_x)
    h2 = get_h(img,0,bd_y,bd_x,len_x)
    h3 = get_h(img,bd_y,len_y,0,bd_x)
    h4 = get_h(img,bd_y,len_y,bd_x,len_x)
    p = h1 + h2 + h3 + h4   #get p
    v = ""
    for i in range(12):     #get v(p)
        if p[i] < 0.3:
            p[i] = 0
            v += "00"
        elif p[i] <0.6:
            p[i] = 1
            v += "01"
        else:
            p[i] = 2
            v += "11"
    g = ""             #get g(p)
    for i in I:
        g += v[i]
    return p,g

I = [1,4,7,10,13,16,19,22]     #I in lsh
folder = 'data_html' #存储结果的文件夹，没有的话会创建一个同名的
if not os.path.exists(folder):
    os.mkdir(folder)
htmlpath = "bili_html" #这是第一步爬虫得到的 bili_html的路径，前面部分改一下
datapath = "data_html" #这是第二步将要进行的数据读取后存放结果的data_html的路径，前面部分改一下
picpath = "pic"     #document for pics
pathDir = os.listdir(htmlpath)
p1 = re.compile('"aid":\d+,"videos":\d+,"tid":\d+,"tname":".{1,50}","copyright":\d+,"pic":".{1,100}\.jpg","title":".{1,200}",.{1,1200}"dynamic"')
p_num = re.compile('\d+')
p_title = re.compile('"title":".{1,200}","pubdate"')
p_jpg = re.compile('"pic":".{1,100}\.jpg",')
aid = open("av.txt", "w")#这是用来放已经爬取过的所有视频的av号的txt文件，前面部分还是改一下
for allDir in pathDir:
    filepath = os.path.join(htmlpath, allDir)
    f1 = open(filepath,"r")
    datalist1 = p1.findall(f1.read())
    for i in range(len(datalist1)):
        numbers = p_num.findall(datalist1[i])
        av_id = numbers[0]
        videos = numbers[1]
        tid = numbers[2]
        title = p_title.findall(datalist1[i])[0][9:-11]
        jpg = p_jpg.findall(datalist1[i])[0][7:-2]
        
        pic_filename = picpath+'/'+av_id   #filename of pic
        urllib.urlretrieve(jpg,pic_filename)    #get pic
        img = cv2.imread(pic_filename,cv2.IMREAD_COLOR)
        pic_feature,pic_type = get_feature(img,I)
        pic_feature = ' '.join([str(i) for i in pic_feature])
        pic_type = ' '.join([str(i) for i in pic_type])
        
        view = numbers[-9]
        danmaku = numbers[-8]
        reply = numbers[-7]
        favorite = numbers[-6]
        coin = numbers[-5]
        share = numbers[-4]
        score = 0
        if int(view) > 0:
            view_score = math.log(int(view))
            if view_score > 14:
                view_score = 50
            else:
                view_score *= (50/14)
            coin_score = int(coin)/int(view)
            if coin_score > 0.5:
                coin_score = 20
            else:
                coin_score *= 40
            favorite_score = int(favorite)/int(view)
            if favorite_score > 0.5:
                favorite_score = 30
            else:
                favorite_score *= 60
            score = view_score+coin_score+favorite_score
        else:
            score = 0
        aid.write(av_id+'\n')
        dataDir = os.path.join(datapath, av_id)
        f2 = open(dataDir, "w")
        f2.write(av_id+"\n"+videos+"\n"+tid+"\n"+title+"\n"+jpg+"\n")
        f2.write(view+"\n"+danmaku+"\n"+reply+"\n"+favorite+"\n"+coin+"\n"+share+"\n"+str(score)+"\n")

        f2.write(pic_type+"\n"+pic_feature+"\n")
        #os.remove(pic_filename)   #remove pic

        f2.close()
    f1.close()
aid.close()
