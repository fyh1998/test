# -*- coding:utf-8 -*-
import urllib2
import re
import urlparse
import os
import urllib
import sys
import time
import threading
import Queue
from bs4 import BeautifulSoup
def valid_filename(s):
    import string
    valid_chars = "-_.() %s%s" % (string.ascii_letters, string.digits)
    s = ''.join(c for c in s if c in valid_chars)
    return s

def get_page(page):
    content = ''
    headers = {
   'Accept': 'text/html, application/xhtml+xml, image/jxr, */*',
   'Accept-Language': 'zh-Hans-CN, zh-Hans; q=0.8, en-GB; q=0.5, en; q=0.3',
   'Connection': 'Keep-Alive',
   'Cookie': ' _cnt_pm=0; _cnt_notify=0; pgv_si=s7935441920; finger=ee9500f4; buvid3=F18CBE0F-CB04-4E24-839C-394705918CEF1978infoc; LIVE_BUVID=730884ca31644259514f234488f3e84c; fts=1511255241; sid=iigxorrn; UM_distinctid=15fde8ffbb1f0e-0523f8252dd4fdc-20d1644-144000-15fde8ffbb2e89; pgv_pvi=8036964352; DedeUserID=18208920; DedeUserID__ckMd5=10bd88b3aca3823f; SESSDATA=1414a6dd%2C1513870432%2C865d1a0b; bili_jct=c3866789a23c035e528bd3fd8a1a576a; LIVE_BUVID__ckMd5=e9278af5ab27cde1; _dfcaptcha=d719aa95818263991ffd3cfc583bf58f; purl_token=bilibili_1511674408; html5_player_gray=false; rpdid=kmimppmmpidosooxmpppw',
   'Host':'api.bilibili.com',
   'Referer': page,
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586'
   }
    try:
        req = urllib2.Request(page,headers=headers)
        response = urllib2.urlopen(req,timeout=1000)
        content = response.read()
    except Exception ,e:
        print e
        pass
    if len(content)>98:  #判断页面数是否已经超出
        return content
    return None

def get_links(seed,num):
    outlinks = []
    index = open("index.txt",'r').readlines()
    base_links=[]
    for line in index:
        rid = line.split()[0]
        base_link = seed+'rid='+rid
        base_links.append(base_link)
    for baselink in base_links:
        for i in range(1,num+1):
            link = baselink+'&pn='+str(i)
            q.put(link)
       
def add_page_to_folder(page, content): #将网页存到文件夹里，将网址和对应的文件名写入index.txt中
    index_filename = 'index.txt'    #index.txt中每行是'网址 对应的文件名'
    folder = 'bili_html'                 #存放网页的文件夹
    filename = valid_filename(page) #将网址变成合法的文件名
    try:
        if not os.path.exists(folder):  #如果文件夹不存在则新建
            os.mkdir(folder)
        f = open(os.path.join(folder, filename), 'w')
        f.write(content)                #将网页存入文件
        f.close()
    except Exception, e:
        print e
        pass

def working():
    while True:
        try:
            page = q.get()
            content = get_page(page)
            if content:
                add_page_to_folder(page,content)
            if varLock.acquire():
                varLock.release()
        except Exception ,e:
            print str(e)+'\t'+str(page)
            pass
        q.task_done()


if __name__ == '__main__':
    seed='http://api.bilibili.com/x/web-interface/newlist?'  #api
    num=1    #每个分区爬取的页面数
    q = Queue.Queue()
    get_links(seed,num)
    varLock = threading.Lock()
    for i in range(1):
        t = threading.Thread(target=working)
        t.setDaemon(True)
        t.start()
    q.join()
