# -*- coding:utf-8 -*-
import urllib2
import threading
import Queue
import os
import re
import requests
import io

def get_page(page):
    content = ''
    headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586'
   }
    try:
        response = requests.get(page,headers = headers)
        content = response.text
    except Exception ,e:
        print e
        pass
    if len(content)>98:  #判断页面数是否已经超出
        return content
    return None

def add_page_to_folder(av, content,t): #将网页存到文件夹里，将网址和对应的文件名写入index.txt中

    if t == 1:
        folder = 'bili_tag'  #存放网页的文件夹
    elif t == 3:
        folder = 'bili_danmu'
    try:
        if not os.path.exists(folder):  #如果文件夹不存在则新建
            os.mkdir(folder)
        f = io.open(os.path.join(folder, av), 'w',encoding = 'utf-8')
        f.write(content)                #将网页存入文件
        f.close()
    except Exception, e:
        print e
        pass

def working():
    while True:
        try:
            page1 = q1.get()
            p1 = page1.split()
            content1 = get_page(p1[1])
            page3 = q3.get()
            p3 = page3.split()
            content3 = get_page(p3[1])
            if content1:
                add_page_to_folder(p1[0],content1,1)
            if content3:
                add_page_to_folder(p3[0],content3,3)
            if varLock.acquire():
                varLock.release()
        except Exception ,e:
            print e
            pass
        q1.task_done()
        q3.task_done()

def get_danmu(link,seed,av):
    content = get_page(link)
    pattern = re.compile(r'cid=(.*?)&aid=')
    try:
        res = re.findall(pattern,content)[0]
    except:
        res = ""
        print "video deleted"
    return seed + res + '.xml'

def get_av(seed1,seed2,seed3,filename):
    ftmp = open(filename,"r")
    av_list = ftmp.readlines()
    for av in av_list:
        av = av.strip()
        link1 = seed1 + av
        q1.put(av+' '+link1)
        link2 = seed2 + av
        link3 = get_danmu(link2,seed3,av)
        q3.put(av+' '+link3)
    
if __name__ == '__main__':
    seed1 = 'http://api.bilibili.com/x/tag/archive/tags?aid=' #api
    seed2 = 'http://www.bilibili.com/video/av'
    seed3 = 'http://comment.bilibili.com/'
    q1 = Queue.Queue()
    q3 = Queue.Queue()
    filename = "C:/Users/lenovo/Desktop/bilibili/av.txt"             #input filename

    get_av(seed1,seed2,seed3,filename)
    varLock = threading.Lock()
    for i in range(10):
        t = threading.Thread(target=working)
        t.setDaemon(True)
        t.start()
    q1.join()
    q3.join()
