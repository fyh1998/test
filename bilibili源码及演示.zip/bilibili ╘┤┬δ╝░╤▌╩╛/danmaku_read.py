# -*- coding:utf-8 -*-
import os
import re
folder = 'data_danmaku'  #存储结果的文件夹，没有的话会创建一个同名的
if not os.path.exists(folder):
    os.mkdir(folder)
p2 = re.compile('">.{1,20}</d><d')
danmakupath = "C:/Users/lenovo/Desktop/bilibili/bili_danmu" #这是第一步爬虫得到的 bili_danmu的路径，前面部分改一下
datapath = "C:/Users/lenovo/Desktop/bilibili/data_danmaku/" #这是第二步将要进行的数据读取后存放结果的data_danmaku的路径，前面部分改一下
pathDir = os.listdir(danmakupath)
for allDir in pathDir:
    filepath1 = os.path.join(danmakupath, allDir)
    filepath2 = os.path.join(datapath, allDir)
    f1 = open(filepath1,"r")
    f2 = open(filepath2,"w")
    datalist = p2.findall(f1.read())
    for danmaku in datalist:
        content=danmaku[2:-6]
        f2.write(content+'\n')
    f1.close()
    f2.close()
